function ElementBuilder(name) {
    this.element = document.createElement(name);

    this.text = function(text) {
        this.element.textContent = text;
        return this;
    };

    this.name = function(name) {
        this.element.name = name;
        return this;
    };

    this.getValue = function() {
        return this.element.value;
    };
    this.setValue = function(value) {
        return (this.element.value = value);
    };

    this.appendTo = function(parent) {
        parent.append(this.element);
        return this;
    };

    this.placeholder = function(placeholder) {
        this.element.placeholder = placeholder;
        return this;
    };

    this.type = function(type) {
        this.element.type = type;
        return this;
    };

    this.styles = function(...styles) {
        this.element.classList.add(...styles);
        return this;
    };

    this.id = function(id) {
        this.element.id = id;
        return this;
    };
    this.onclick = function(func) {
        this.element.onclick = func;
        return this;
    };

    this.onsearch = function(func) {
        this.element.onsearch = func;
        return this;
    };

    this.build = function() {
        return this.element;
    };
}

const builder = {
    create: function(name) {
        return new ElementBuilder(name);
    },
};

function PhoneBookRecord(name, phone) {
    this.name = name;
    this.phone = phone;
}

function PhoneBook() {
    this.records = [];

    this.add = function(name, phone) {
        const newRecord = new PhoneBookRecord(name, phone);
        this.records.unshift(newRecord);
    };

    this.remove = function(name) {
        this.records.splice(this.records.indexOf(name), 1)
    };

    this.search = function(value) {
        return this.records.filter((item) => {
            return item.name.toLowerCase().includes(value.toLowerCase());
        });
    };

    //add search remove functions add here
}

function Render(container) {
    this.container = container;
    let divDetails, errMessage;
    const phoneBook = new PhoneBook();

    this.init = function() {
        const divContent = builder
            .create("div")
            .styles("content")
            .appendTo(this.container)
            .build();

        const contentTitle = builder
            .create("h1")
            .text("Phone Book")
            .styles("title-custom")
            .appendTo(divContent)
            .build();

        const contentIcon = builder
            .create("i")
            .styles("fa", "fa-address-book")
            .appendTo(contentTitle)
            .build();

        const divSearch = builder
            .create("div")
            .styles("inp", "search-box")
            .id("searchBox")
            .appendTo(divContent)
            .build();

        const searchBox = builder
            .create("input")
            .styles("inp-search")
            .id("searchInpt")
            .type("search")
            .placeholder("search")
            .onsearch(() => {
                updatePhoneBook(phoneBook.records);
            })
            .appendTo(divSearch);

        const searchBtn = builder
            .create("button")
            .styles("icon-holder")
            .onclick(() => {
                const searchResult = phoneBook.search(searchBox.getValue());
                if (searchResult.length !== 0) {
                    updatePhoneBook(searchResult);
                } else {
                    errMessage.textContent = "not found!";
                    return;
                }
            })
            .appendTo(divSearch)
            .build();

        const searchIcon = builder
            .create("i")
            .styles("fa", "fa-search")
            .appendTo(searchBtn)
            .build();

        const contactTitle = builder
            .create("h3")
            .text("add new contact")
            .appendTo(divContent)
            .build();

        const nameInpt = builder
            .create("input")
            .styles("inp")
            .type("text")
            .name("name")
            .placeholder("name")
            .appendTo(divContent);

        const phoneInpt = builder
            .create("input")
            .styles("inp")
            .type("text")
            .name("phone")
            .placeholder("phone")
            .appendTo(divContent);

        errMessage = builder
            .create("p")
            .styles("err-message")
            .appendTo(divContent)
            .build();

        const addBtn = builder
            .create("button")
            .text("add")
            .onclick(() => {
                const isChecked = checkValue(nameInpt.getValue(), phoneInpt.getValue());
                if (isChecked === true) {
                    phoneBook.add(nameInpt.getValue(), phoneInpt.getValue());
                    nameInpt.setValue(null);
                    phoneInpt.setValue(null);
                    updatePhoneBook(phoneBook.records);
                }
            })
            .id("addBtn")
            .styles("pbbutton")
            .appendTo(divContent);

        const hr = builder.create("hr").appendTo(divContent).build();

        const divTitle = builder.create("div").appendTo(divContent).build();

        divDetails = builder
            .create("div")
            .id("divDetails")
            .styles("pbTable")
            .appendTo(divContent)
            .build();

        const ulListTitle = builder
            .create("ul")
            .styles("phone-book-title")
            .appendTo(divTitle)
            .id("uirow")
            .build();

        const liName = builder
            .create("li")
            .appendTo(ulListTitle)
            .text("Name")
            .build();

        const liPhone = builder
            .create("li")
            .appendTo(ulListTitle)
            .text("Phone")
            .build();
    };

    function checkValue(name, phone) {
        errMessage.textContent = "";
        const txtname = name;
        const txtphone = phone;
        if (txtname === "" || txtphone === "") {
            errMessage.textContent = "Please enter a valid name and phone number!";
            return (isChecked = false);
        }

        if (!Number(txtphone)) {
            errMessage.textContent = "Phone number is not valid!";
            return (isChecked = false);
        }
        let isDuplicated = false;
        phoneBook.records.forEach((item) => {
            if (item.phone === txtphone) {
                errMessage.textContent = "This number already exists!";
                isDuplicated = true;
            }
        });
        if (isDuplicated) {
            return (isChecked = false);
        }

        return (isChecked = true);
    }

    function updatePhoneBook(items) {
        divDetails.innerHTML = "";
        const divDetail = builder
            .create("ul")
            .styles("phone-book-detail")
            .appendTo(divDetails)
            .build();
        items.forEach((item) => {
            const detailP1 = builder.create("li").text(item.name).appendTo(divDetail)
                .build();
            const detailP2 = builder
                .create("li")
                .text(item.phone)
                .appendTo(divDetail)
                .build();

            const removeBtn = builder
                .create("button")
                .styles("btn-remove")
                .appendTo(divDetail)
                .build();

            const removeIcon = builder
                .create("i")
                .styles("fa", "fa-minus-circle", "remove-icon")
                .onclick(() => {
                    phoneBook.remove(item);
                    updatePhoneBook(phoneBook.records);
                })
                .appendTo(removeBtn)
                .build();
        });
    }
}
const phoneBookContainer = document.getElementById("phone-book-container");
const app = new Render(phoneBookContainer);
app.init();